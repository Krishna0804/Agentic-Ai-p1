import { CampusDashboard } from "@/components/campus-dashboard"

export default function HomePage() {
  return (
    <main className="min-h-screen bg-background">
      <CampusDashboard />
    </main>
  )
}
